uang = int (input ("Uang yang anda miliki: "))
harga = 2000000
int (harga)
hasil = int (uang/harga)
print ("anda mendapatkan", hasil, "unit nintendo wii")
tambahan = ((hasil+1)*harga)-uang
print ("anda harus menambah Rp" , tambahan, "untuk nintendo wii tambahan")
