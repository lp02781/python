angka = input ("masukkan angka")
int(angka)
sum =1
for hasil in range (int(angka), 0, -1):
    sum=sum*hasil                       #bikin fungsi perulangan
print("hasil",sum)
    
    
