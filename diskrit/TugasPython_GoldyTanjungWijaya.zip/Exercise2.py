for x in range (99,0, -1):
    if (x>1):
        print (x, "bottles of beer")
    else:
        print (x, "bottle of beer")
