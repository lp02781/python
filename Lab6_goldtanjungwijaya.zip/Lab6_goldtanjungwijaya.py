perulangan= int(input(""))
dict_makanan = {}
z=[]
for i in range (0,perulangan):
    perintah=input("")
    y=perintah.split()
    z.append(y)
    makanan=z[i][1]
    if y[0]=='NEW':
        if y[1] not in dict_makanan:
            dict_makanan[makanan]=0
            print("Berhasil menambahkan antrian untuk menu "+y[1])
        elif y[1] in dict_makanan:
            print("Menu "+y[1]+" sudah ada")
            print(dict_makanan)
    if y[0]=='ADD':
        if y[1] not in dict_makanan:
            print("Tidak ada menu "+y[1])
        else:
            print(y[2]+" mengantri untuk membeli "+y[1]+" sebanyak "+y[3]+" porsi")
            print(z)
            total=0
            if i<0:
                pos=
            total=total+int(z[pos][3])
            pos+=1
            dict2={y[1]:total}
            dict_makanan.update(dict2)
            print(dict_makanan)
                
    if y[0]=='SERVE':
        if y[1] not in dict_makanan:
            print("Tidak ada menu "+y[1])
        elif y[1] in dict_makanan and dict_makanan.pop(y[1]):
            print("menyajikan "+y[2]+" porsi "+y[1]+" kepada "+y[2]+", "+y[2]+" pulang dengan senang")
        else: 
            print("Antrian "+y[1]+" kosong")
    if y[0]=='HABIS':
        if y[1] not in dict_makanan:
            print("Tidak ada menu "+y[1])
        else:
            print("menu "+y[1]+" telah habis dan antriannya ditutup")
            dict_makanan.pop(y[1])
            
