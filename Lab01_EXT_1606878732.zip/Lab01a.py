import math
nama = input ("Masukkan nama anda: ")
tahun = int(input ("Masukkan tahun kelahiran anda: "))
tinggal = input ("Masukkan tempat tinggal anda: ")
umur = 2017 - tahun
int (umur)
x = str(umur)
print (nama+' berumur' ,umur,'tinggal di '+tinggal)
