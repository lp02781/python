import aktivitas

class Motor():
	def __init__(self, gigi1, gigi2, gigi3, gigi4, kapasitas):
		self.gigi1 = gigi1
		self.gigi2 = gigi2
		self.gigi3 = gigi3
		self.gigi4 = gigi4
		self.kapasitas = kapasitas
		self.isiTangki = 0

	def getGigi1(self):
		return self.gigi1

	def getGigi2(self):
		return self.gigi2

	def getGigi3(self):
		return self.gigi3

	def getGigi4(self):
		return self.gigi4

	def getKapasitas(self):
		return self.kapasitas 

	def getIsiTangki(self):
		return self.isiTangki

	def setGigi1(self, gigi1):
		self.gigi1 = gigi1

	def setGigi2(self, gigi2):
		self.gigi2 = gigi2

	def setGigi3(self, gigi3):
		self.gigi3 = gigi3

	def setGigi4(self, gigi4):
		self.gigi4 = gigi4

	def setKapasistas(self, kapasitas):
		self.kapasistas = kapasistas

	def setIsiTangki(self, isiTangki):
		self.isiTangki = isiTangki

motor1 = Motor(1,2,3,4,9)
motor2 = Motor(2,3,4,5,16)
motor3 = Motor(2,3,4,5,22)

#motor 1 menambahkan bensin sebanyak 5 Liter
aktivitas.addBensin(motor1, 5) #print: 	Bensin telah ditambahkan sebanyak 5 Liter
							   #		Total bensin yang tersedia sekarang sebanyak 5 Liter

#motor 1 menambahkan bensin sebanyak 5 Liter
aktivitas.addBensin(motor1, 5) #print: 	Bensin terisi penuh
							   #		Sisa bensin yang belum diisikan sebanyak 1 Liter

#motor 1 berjalan menggunakan gear 2, sejauh 16km
aktivitas.drive(motor1, 2, 16) #print: 	Motor telah berjalan sejauh 16 km
							   #		Sisa bensin yang tersedia sebanyak 1 liter.

#motor 1 berjalan menggunakan gear 1, sejauh 4km
aktivitas.drive(motor1, 1, 4)  #print: 	Motor telah berjalan sejauh 1 km.
							   #		Bensin habis.
							   #		Sisa jarak yang belum ditempuh sejauh 3 km.

aktivitas.cekKategori(motor1)  # print: Motor Jadul
aktivitas.cekKategori(motor2)  # print: Motor Bebek
aktivitas.cekKategori(motor3)  # print: Motor Balap